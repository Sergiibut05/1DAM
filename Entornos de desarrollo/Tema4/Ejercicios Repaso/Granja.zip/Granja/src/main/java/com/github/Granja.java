package com.github;

public class Granja {
    private String nombre;
    private double m2;
    private Animal[] tiene;
}
