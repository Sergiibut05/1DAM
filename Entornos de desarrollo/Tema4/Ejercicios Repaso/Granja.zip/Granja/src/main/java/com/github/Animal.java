package com.github;

public abstract class Animal {

    protected Especie especie;

    public static int numeroAdultos;

    private Granja viveEn;

    public abstract void relacionarse();
}
