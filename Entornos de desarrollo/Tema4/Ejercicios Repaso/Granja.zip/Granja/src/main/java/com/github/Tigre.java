package com.github;

public class Tigre extends Animal implements Carnivoro {
    @Override
    public void relacionarse() {
        System.out.println("Soy un tigre y me estoy relacionando");
    }

    @Override
    public void cazar() {
        System.out.println("Soy un tigre y estoy cazando");
    }
}
