package com.github;

public interface Carnivoro {
    public void cazar();
}
