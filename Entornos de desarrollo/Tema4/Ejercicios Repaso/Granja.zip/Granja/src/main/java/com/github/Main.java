package com.github;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        /*
         * Ejemplo de uso. Creamos un array de la clase
         * abstracta Animal. Las clases abstractas no
         * se pueden instanciar directamente, pero sí
         * se puede instanciar uno de sus "herederos"
         * y meterlo en el array de Animal. Recorremos
         * ese array y llamamos al método relacionarse()
         *
         * Cada subclase implementará el método de una manera
         * distinta y hará lo que en esa subclase se considere.
         *
         * En este ejemplo, simplemente se muestra un mensaje:
         * Las vacas muestran un mensaje y los tigres otro.
         *
         * Se puede hacer exactamente igual si en lugar de
         * una herencia es una implementación de interfaz.
         */

        Animal[] animals;

        animals = new Animal[4];

        animals[0] = new Vaca();
        animals[1] = new Tigre();
        animals[2] = new Tigre();
        animals[3] = new Vaca();

        for (int i=0; i<animals.length; i++) {
            animals[i].relacionarse();
        }
    }
}