package com.github;

public enum Especie {
    MAMIFERO, OVIPARO, REPTIL, ANFIBIO
}
