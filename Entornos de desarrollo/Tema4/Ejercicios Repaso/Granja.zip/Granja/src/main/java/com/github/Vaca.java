package com.github;

public class Vaca extends Animal implements Herbivoro {

    @Override
    public void relacionarse() {
        System.out.println("Soy una vaca y me estoy relacionando");
    }

    @Override
    public void buscarPlantas() {
        System.out.println("Soy una vaca y estoy buscando plantas");
    }
}
