package com.github;

public interface Herbivoro {
    public void buscarPlantas();
}
