/**
 * Clase para gestionar información de contactos empresariales.
 * Almacena nombre, apellidos, cargo, email, teléfono e identificador.
 * 
 * Los atributos son:
 * - nombre: String con el nombre del contacto
 * - apellidos: String con los apellidos del contacto  
 * - cargo: String con el puesto o cargo en la empresa
 * - email: String con el correo electrónico profesional
 * - telefono: String con el número de teléfono de contacto
 * - id: Integer con el identificador único del contacto
 * 
 * Implementa la interfaz Serializable para permitir la persistencia.
 */
public class Contacto implements IContacto {
    
    
    /**
     * Constructor para inicializar un nuevo contacto sin ID asignado.
     * 
     * @param nombre Nombre del contacto
     * @param apellidos Apellidos del contacto
     * @param cargo Cargo o puesto en la empresa
     * @param email Correo electrónico
     * @param telefono Número de teléfono
    */

    private String nombre;
    private String apellidos;
    private String cargo;
    private String email;
    private String telefono;
    private Integer id;

    public Contacto(String nombre, String apellidos, String cargo, String email, String telefono) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.cargo = cargo;
        this.email = email;
        this.telefono = telefono;
    }
    
    /**
     * Constructor para inicializar un nuevo contacto con ID específico.
     * 
     * @param id Identificador único del contacto
     * @param nombre Nombre del contacto
     * @param apellidos Apellidos del contacto
     * @param cargo Cargo o puesto en la empresa
     * @param email Correo electrónico
     * @param telefono Número de teléfono
     */

    
    public Contacto(Integer id, String nombre, String apellidos, String cargo, String email, String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.cargo = cargo;
        this.email = email;
        this.telefono = telefono;
    }
    
    /**
     * Constructor que inicializa un contacto a partir de una cadena serializada.
     * El formato esperado es: id;nombre;apellidos;cargo;email;telefono
     * 
     * @param cadena La cadena serializada con el ID y datos del contacto
     * @throws IllegalArgumentException Si el formato de la cadena es inválido
     * @throws NumberFormatException Si el ID no es un número válido
     */
    public Contacto(String cadena) {
        int contador = 0;
        int lastdivision = 0;
        String dato;
        for(int i=0; i < cadena.length(); i++){
            if(cadena.charAt(i) == ';'){
                contador++;
            }
        }
        if(contador != 5){
            throw new IllegalArgumentException("La cadena no es valida");
        }
        contador = 0;
        try{
            for(int i=0; i < cadena.length(); i++){
                if(cadena.charAt(i) == ';'){
                    contador++;
                    dato = cadena.substring(lastdivision, i);
                    lastdivision = i+1;
                    switch (contador) {
                        case 1:
                            this.id = Integer.parseInt(dato);
                            break;
                        case 2:
                            this.nombre = dato;
                            break;
                        case 3:
                            this.apellidos = dato;
                            break;
                        case 4:
                            this.cargo = dato;
                            break;
                        case 5:
                            this.email = dato;
                            break;
                        default:
                            break;
                    }
                }
                if(contador == 6){
                    this.telefono = cadena.substring(lastdivision, cadena.length()-1);
                }
                if(contador == 5){
                    contador++;
                }
                
            } 
        }catch (NumberFormatException e){

        }catch (Exception e){
            
        }   
        
        
    }

    @Override
    public String nombreCompleto() {
        // TODO Auto-generated method stub
        return String.format("%s %s",nombre,apellidos);
    }

    @Override
    public void setNombre(String nombre) {
        // TODO Auto-generated method stub
        this.nombre = nombre;
    }

    @Override
    public void setApellidos(String apellidos) {
        // TODO Auto-generated method stub
        this.apellidos = apellidos;
    }

    @Override
    public void setEmail(String email) {
        // TODO Auto-generated method stub
        this.email = email;
    }

    @Override
    public void setTelefono(String telefono) {
        // TODO Auto-generated method stub
        this.telefono = telefono;
    }

    @Override
    public void setCargo(String cargo) {
        // TODO Auto-generated method stub
        this.cargo = cargo;
    }

    @Override
    public void setId(Integer id) {
        // TODO Auto-generated method stub
        this.id = id;
    }

    @Override
    public String getNombre() {
        // TODO Auto-generated method stub
        return nombre;
    }

    @Override
    public String getApellidos() {
        // TODO Auto-generated method stub
        return apellidos;
    }

    @Override
    public String getCargo() {
        // TODO Auto-generated method stub
        return cargo;
    }

    @Override
    public String getEmail() {
        // TODO Auto-generated method stub
        return email;
    }

    @Override
    public String getTelefono() {
        // TODO Auto-generated method stub
        return telefono;
    }

    @Override
    public Integer getId() {
        // TODO Auto-generated method stub
        return id;
    }

    @Override
    public String toString(){
        return String.format("""
            🔖 FICHA DE CONTACTO
            🔑 ID: %d
            👤 Nombre:   %s
            💼 Cargo:    %s
            📧 Email:    %s
            📞 Teléfono: %s
                """,id,nombreCompleto(),cargo,email,telefono);
    }

    @Override
    public String serializar() {
        // TODO Auto-generated method stub
        return String.format("%d;%s;%s;%s;%s;%s",id,nombre,apellidos,cargo,email,telefono);
    }
    
} 