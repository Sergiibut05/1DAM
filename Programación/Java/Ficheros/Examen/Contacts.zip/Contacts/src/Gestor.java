import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Implementación de la interfaz IGestor para la clase Contacto.
 * Gestiona una colección de contactos permitiendo operaciones CRUD y persistencia.
 * 
 * Los atributos son:
 * - contactos: HashMap que almacena los contactos usando el ID como clave
 * - nextId: Entero que mantiene el siguiente ID disponible para nuevos contactos
 * - nombreArchivo: String con la ruta del archivo para persistencia de datos
 */
public class Gestor implements IGestor<Contacto> {
    private HashMap<Integer, Contacto> contactos;
    private int nextId;
    private String nombreArchivo;
    /**
     * Constructor que inicializa el gestor con un archivo específico.
     * 
     * @param nombreArchivo El nombre del archivo .data para persistencia
     */
    public Gestor(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
        this.contactos = new HashMap<>();
        cargarDesdeArchivo();
        this.nextId = contactos.size()+1;
    }
    
    /**
     * Constructor por defecto que inicializa el gestor sin archivo.
     */
    public Gestor() {
        this.contactos = new HashMap<>();
    }

    @Override
    public int agregar(Contacto entidad) {
        // TODO Auto-generated method stub
        int idNuevoContacto = nextId;
        this.nextId ++;
        entidad.setId(idNuevoContacto);
        contactos.put(idNuevoContacto, entidad);
        guardarEnArchivo();
        return idNuevoContacto;
    }

    @Override
    public boolean actualizar(int id, Contacto entidadActualizada) {
        // TODO Auto-generated method stub
        if(contactos.containsKey(id)){
            entidadActualizada.setId(id);
            contactos.put(id, entidadActualizada);
            guardarEnArchivo();
            return true;
        }
        return false;
    }

    @Override
    public boolean eliminar(int id) {
        // TODO Auto-generated method stub
        if(contactos.containsKey(id)){
            contactos.remove(id);
            guardarEnArchivo();
            return true;
        }
        return false;
    }

    @Override
    public Contacto buscarPorId(int id) {
        // TODO Auto-generated method stub
        if(contactos.containsKey(id)){
            return contactos.get(id);
        }
        return null;
    }

    @Override
    public List<Contacto> listarTodos() {
        // TODO Auto-generated method stub
        List<Contacto> copiaContactos = new ArrayList<>();
        for (Contacto contacto : contactos.values()) {
            copiaContactos.add(contacto);
        }
        return (List)copiaContactos;
    }

    @Override
    public void setNombreArchivo(String nombreArchivo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setNombreArchivo'");
    }

    @Override
    public int cargarDesdeArchivo() {
        // TODO Auto-generated method stub
        File file = new File(nombreArchivo);
        int contador = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            Contacto newContacto;
            while((line = br.readLine()) != null){
                newContacto = new Contacto(line);
                this.contactos.put(newContacto.getId(), newContacto);
                contador++;
            } 
        } catch (IOException e) {
            // TODO: handle exception
            e.getStackTrace();
        } catch (Exception e){
        }
        return contador;
    }

    @Override
    public boolean guardarEnArchivo() {
        // TODO Auto-generated method stub
        File file = new File(nombreArchivo);
        int contador = 0;
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file,false))) {
            String line;
            for (Contacto t : contactos.values()) {
                bw.write(t.serializar());
                contador++;
                bw.newLine();
            }
        } catch (IOException e) {
            // TODO: handle exception
            e.getStackTrace();
        } catch (Exception e){
        }
        if(contador == contactos.size()){
            return true;
        }
        return false;
    }
    
    
} 