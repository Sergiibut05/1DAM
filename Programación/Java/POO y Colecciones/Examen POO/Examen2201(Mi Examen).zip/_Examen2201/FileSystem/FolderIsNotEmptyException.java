package FileSystem;

public class FolderIsNotEmptyException extends Exception{
    
}
