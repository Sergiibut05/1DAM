package FileSystem;

import java.util.Date;

/** clase Folder
 * Hereda de la clase File e implementa la interfaz FolderEntry
 * La clase Folder mantiene una lista de archivos/carpetas así como una referencia
 * a la carpeta que la contiene
 * La clase Folder al heredar de la clase File hereda sus propiedades
 * name, level y createdAt
 * Además dispondrá de un array donde se irán añadiendo los archivos que están dentro de
 * la carpeta
 * Debe implementar la interfaz FolderEntry
 * Debe tener un constructor que recibirá la carpeta que la contiene, en el caso
 * de que sea la carpeta raiz, recibirá null en la referencia a la carpeta padre
 * Además el constructor recibirá el nombre de la carpeta así como el nivel en el que se
 * encuentra la carpeta (Nivel 0 es la carpeta raiz, Nivel 1 las carpetas hijas de la carpeta raiz,
 * y así sucesivamente)
 * Ejemplo de llamada al constructor:
 * Folder root = new Folder(null, "Raiz", 0);
 * 
 */
public class Folder extends File implements FolderEntry{
    private Folder parent;
    private File[] files;

    public Folder(Folder parent, String fileName, int nivel){
        super(fileName);
        this.createdAt = new Date();
        this.nivel = nivel;
        this.parent = parent;
        files = new File[100];
    }
    @Override
    public boolean isDirectory() {
        // TODO Auto-generated method stub
        boolean isDirectory = true;

        return isDirectory;
    }
    @Override
    public Folder getParent() {
        // TODO Auto-generated method stub
        return parent;
    }

    @Override
    public boolean isFolderFull() {
        // TODO Auto-generated method stub
        boolean full = true;
        for(int i=0;i<files.length;i++){
            if(files[i]==null){
                full = false;
                break;
            }
        }
        return full;
    }

    @Override
    public int getFileCount() {
        // TODO Auto-generated method stub
        int contador =0;
        for(int i=0; i<files.length;i++){
            if(files[i]==null){
                break;
            }else{
                contador++;
            }
        }
        return contador;
    }

    @Override
    public boolean isFileInFolder(String fileName) {
        // TODO Auto-generated method stub
        boolean isFileInFolder = false;
        for(int i=0;i<files.length;i++){
            if(files[i]!=null && files[i].getName().equals(fileName)){
                isFileInFolder = true;
                break;
            }
        }
        return isFileInFolder;
    }

    @Override
    public Folder addFolder(String folderName) throws FolderIsFullException, FileAlreadyExistsException {
        // TODO Auto-generated method stub
        Folder carpeta = null;
        if(!isFileInFolder(folderName)){
            throw new FileAlreadyExistsException();
        }else{
            if(isFolderFull()){
                throw new FolderIsFullException();
            }else{
                int posicion = getFileCount();
                carpeta = new Folder(getParent(), folderName, this.nivel+1);
                files[posicion] = carpeta;
            }
        }
        return carpeta;
    }

    @Override
    public File addFile(String fileName) throws FolderIsFullException, FileAlreadyExistsException {
        // TODO Auto-generated method stub
        File nuevo = null;
        if(isFileInFolder(fileName)){
            throw new FileAlreadyExistsException();
        }else{
            if(isFolderFull()){
                throw new FolderIsFullException();
            }else{
                int posicion = getFileCount();
                nuevo = new File(fileName);
                files[posicion] = nuevo;
            }
        }
        return nuevo;
    }

    @Override
    public File removeFile(String fileName) throws FileDoesNotExistsException {
        int posicion = -1;
        File borrado = null;
        // TODO Auto-generated method stub
        for(int i=0; i<files.length;i++){
            if(files[i].getName().equals(fileName)){
                posicion = i;
                borrado = files[i];
                files[i] = null;
                break;
            }
        }
        if(posicion == -1){
            throw new FileDoesNotExistsException();
        }
        return borrado;
    }

    @Override
    public File removeFolder(String folderName, boolean recursive) throws FileDoesNotExistsException, FolderIsNotEmptyException {
        // TODO Auto-generated method stub
        File borrado = null;
        for(int i=0;i<=files.length;i++){
            if(files[i].getName().equals(folderName)){
                borrado = getFolder(folderName);
                files[i] = null;
                if(files[i]!=null){
                    throw new FolderIsNotEmptyException();
                }
                break;
            }
        }
        if(borrado == null){
            throw new FileDoesNotExistsException();
        }
        return borrado;
    }

    @Override
    public Folder getFolder(String folderName) throws FileDoesNotExistsException {
        // TODO Auto-generated method stub
        Folder folder = null;
        for(int i=0;i<=files.length;i++){
            if(files[i].getName().equals(folderName)){
                folder = (Folder) files[i];
            }
        }
        if(folder == null){
            throw new FileDoesNotExistsException();
        }
        return folder;
    }
    @Override 
    public String toString(){

        return String.format("|_[%s] \n",super.getName());
    }

    
}
