package FileSystem;

public class FileAlreadyExistsException extends Exception{
    
}
