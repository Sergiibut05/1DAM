package library;
import java.util.HashSet;
import java.util.ArrayList;

/**
 * Implementación genérica de un catálogo que puede almacenar cualquier tipo de elemento.
 * Mantiene un conjunto de elementos únicos y proporciona operaciones básicas para su gestión.
 * @param <T> tipo de elementos que almacenará el catálogo
 */
public class Catalog<T> implements ICatalog<T> {
    private ArrayList<T> almacenamiento;

    public Catalog(){
        this.almacenamiento = new ArrayList<>();
    }

    @Override
    public boolean addItem(T item) {
        // TODO Auto-generated method stub
        if(almacenamiento.contains(item)){
            return false;
        }else{
            almacenamiento.add(item);
            return true;
        }
    }

    @Override
    public void removeItem(T item) {
        // TODO Auto-generated method stub
        if(almacenamiento.contains(item)){
            almacenamiento.remove(item);
        }
    }

    @Override
    public ArrayList<T> getAllItems() {
        // TODO Auto-generated method stub
        ArrayList copia = new ArrayList<>();
        for (T t : almacenamiento) {
            copia.add(t);
        }
        return copia;
    }

    
} 