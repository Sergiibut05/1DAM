package library;
/**
 * Clase que representa un libro en la biblioteca.
 * Contiene la información básica de un libro: título, autor, ISBN y año de publicación.
 * Dos libros se consideran iguales si tienen el mismo ISBN.
 */
public class Book implements IBook {
    private String title;
    private String author;
    private String isbn;
    private int publicationYear;

    public Book(String title, String author, String isbn, int publicationYear){
        String yearPublication = String.format("%d", publicationYear);
        if(title == null || author == null || isbn == null || yearPublication == null){
            throw new IllegalArgumentException("Ningún campo puede ser null");
        }
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.publicationYear = publicationYear;
    }
    @Override
    public boolean equals(Object a){
        if(this == (Book) a){
            return true;
        }
        if(this.getClass()!=a.getClass()){
            return false;
        }
        Book b = (Book) a;
        return (this.isbn.equals(b.getIsbn()));
    }
    @Override
    public int hashCode(){
        return isbn.hashCode();
    }

    @Override
    public String getTitle() {
        // TODO Auto-generated method stub
        return title;
    }

    @Override
    public String getAuthor() {
        // TODO Auto-generated method stub
        return author;
    }

    @Override
    public String getIsbn() {
        // TODO Auto-generated method stub
        return isbn;
    }

    @Override
    public int getPublicationYear() {
        // TODO Auto-generated method stub
        return publicationYear;
    }

    @Override
    public String toString(){
        return String.format("""
                Book{title='%s', author='%s', isbn='%s', publicationYear=%d}
                """, title,author,isbn,publicationYear);
    }



} 