package library;
import java.util.ArrayList;
import java.util.HashMap;
import library.exceptions.*;

/**
 * Implementación de una biblioteca que gestiona una colección de libros.
 * Utiliza un catálogo para almacenar los libros y un HashMap para acceso rápido por autor.
 */
public class Library<T> implements ILibrary {
    private Catalog catalogo;
    private HashMap<T, ArrayList<Book>> quickAccess;
    
    

    public Library(){
        this.catalogo = new Catalog<Book>();
        this.quickAccess = new HashMap<>();
        
    }

    @Override
    public void addBook(Book book) throws DuplicateBookException {
        // TODO Auto-generated method stub
        ArrayList arrayList = catalogo.getAllItems();
        if(arrayList.contains(book)){
            throw new DuplicateBookException(null);
        }else{
            catalogo.addItem(book);
            if(quickAccess.containsKey(book.getAuthor())){
                ArrayList<Book> original1 = quickAccess.get(book.getAuthor());
                original1.add(book);
                quickAccess.put((T)book.getAuthor(), original1);
            }else{
                ArrayList<Book> nuevo1 = new ArrayList<>();
                nuevo1.add(book);
                quickAccess.put((T)book.getAuthor(),nuevo1);
            }
            if(quickAccess.containsKey(book.getPublicationYear())){
                ArrayList<Book> original2 = quickAccess.get(book.getPublicationYear());
                original2.add(book);
                quickAccess.put((T)(Integer)book.getPublicationYear(), original2);
            }else{
                ArrayList<Book> nuevo2 = new ArrayList<>();
                nuevo2.add(book);
                quickAccess.put((T)(Integer)book.getPublicationYear(), nuevo2);
            }
        }
    }

    @Override
    public void removeBook(String isbn) throws BookNotFoundException {
        Book book = findByIsbn(isbn);
        ArrayList<Book> author = quickAccess.get(book.getAuthor());
        author.remove(book);
        quickAccess.put((T)book.getAuthor(), author);
        ArrayList<Book> year = quickAccess.get(book.getPublicationYear());
        year.remove(book);
        quickAccess.put((T)(Integer)book.getPublicationYear(), year);
        catalogo.removeItem(book);
    }

    @Override
    public Book findByIsbn(String isbn) throws BookNotFoundException {
        // TODO Auto-generated method stub
        Book prueba = null;
        ArrayList arrayList = catalogo.getAllItems();
        for (Object object : arrayList) {
            prueba = (Book) object;
            if(isbn.equals(prueba.getIsbn())){
                return prueba;
            }
        }
        throw new BookNotFoundException(isbn);
    }

    @Override
    public ArrayList<Book> findByAuthor(String author) {
        // TODO Auto-generated method stub
        if(author == null){
            throw new IllegalArgumentException("¡Esto no es aceptable!");
        }
        if(quickAccess.containsKey(author)){
            ArrayList<Book> porAutor = quickAccess.get(author);
            return porAutor;
        }else{
            return new ArrayList<Book>();
        }
    }

    @Override
    public ArrayList<Book> findByYear(int year) {
        // TODO Auto-generated method stub
        String anio = String.format("%d", year);
        if(anio == null){
            throw new IllegalArgumentException("¡Esto no es aceptable!");
        }
        if(quickAccess.containsKey(year)){
            ArrayList<Book> porAnio = quickAccess.get(year);
            return porAnio;
        }else{
            return new ArrayList<Book>();
        }
    }

    @Override
    public ArrayList<Book> getAllBooks() {
        // TODO Auto-generated method stub
        ArrayList<Book> allbooks = new ArrayList<>();
        for (Object book : catalogo.getAllItems()) {
            allbooks.add((Book)book);
        }
        return allbooks;
    }

} 