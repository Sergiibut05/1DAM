package eticket;

public class NotEnoughStock extends Exception {
    
}
