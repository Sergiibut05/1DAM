import Tarea1.Tarea1;
import Tarea2.Tarea2;
import Tarea3.Tarea3;
import Tarea4.Tarea4;
import Tarea5.Tarea5;
import Tarea6.Tarea6;
public class App {
    public static void main(String[] args) throws Exception {
        Tarea1.tarea1();
        Tarea2.tarea2();
        Tarea3.tarea3();
        Tarea4.tarea4();
        Tarea5.tarea5();
        Tarea6.tarea6();
    }
}
