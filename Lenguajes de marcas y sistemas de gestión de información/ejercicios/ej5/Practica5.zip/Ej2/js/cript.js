function cambiarTamano() {
    let img = document.getElementById("betis1");
    img.width = 750;
    img.height = 450;
}

function cambiarImagen() {
    document.getElementById("betis1").src = "recursos/betis2.jpg";
}
