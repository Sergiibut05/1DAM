function cambiarColorTitulo() {
    document.getElementById("titulo").style.color = "red";
}

function ponerNegritaParrafo() {
    document.getElementById("parrafo").style.fontWeight = "bold";
}
