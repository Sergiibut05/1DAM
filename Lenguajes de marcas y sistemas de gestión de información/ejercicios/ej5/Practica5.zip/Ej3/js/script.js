function mostrarContenedor2() {
    document.getElementById("contenedor1").style.display = "none";
    document.getElementById("contenedor2").style.display = "block";
}

function mostrarContenedor1() {
    document.getElementById("contenedor2").style.display = "none";
    document.getElementById("contenedor1").style.display = "block";
}
